#!/bin/bash

# Get current New York time in YYYYMMDD_HHMM format


# Get current New York time in YYYYMMDD_HHMM format
NY_TIME=$(TZ="America/New_York" date +"%Y%m%d_%H%M")
NY_HM=$(TZ="America/New_York" date +"%H:%M")

# If not 09:30 New York time, sleep 2s
if [ "$NY_HM" != "09:30" ]; then
    sleep 5
fi



# Define base log directory
LOG_DIR="/home/user7496/Desktop/s2prox_jobs/logfile"



# Make sure log directory exists
mkdir -p "$LOG_DIR"

# --- Step 1: Kill Docker containers ---
echo "----- $(date) -----" | tee -a "$LOG_DIR/kill_$NY_TIME.log"
sudo docker kill $(sudo docker ps -q) >> "$LOG_DIR/kill_$NY_TIME.log" 2>&1


# --- Step 3: Run TSLA_SHORT.py ---
echo "----- $(date) -----" | tee -a "$LOG_DIR/9p6_TSLA_LONG_4B_$NY_TIME.log"
/usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/TSLA_SHORT_4B.py >> "$LOG_DIR/9p6_TSLA_LONG_4B_$NY_TIME.log" 2>&1



