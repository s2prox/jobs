import os
import subprocess
from datetime import datetime, timedelta
import pandas_market_calendars as mcal
import pytz

# Original crontab jobs as a string

original_crontab = """
#  make sure vm work smoothly



#################### Preparation work ############################## 

1 3 1-5 * * sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox ubuntu bash -c "rm -f /app/downloads/s2prox/*.csv"

10,20 8-15 * * 1-5 (echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/close_price.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/close_price.log 2>&1

11,21 8-15 * * 1-5 (echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/close_price_SOXS80.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/close_price.log 2>&1


0 * * * * sudo pkill -f JxBrowser
10 3 * * 1-5 rm -f /home/user7496/Desktop/s2prox_jobs/logfile/*
20 3 * * * rm -rf $HOME/.local/share/Trash/files/* $HOME/.local/share/Trash/info/*

25 9 * * 1-5 (echo "----- $(date) -----" && sudo docker kill $(sudo docker ps -q)) >> /home/user7496/Desktop/s2prox_jobs/logfile/kill.log 2>&1


46,55 14-15 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl.log 2>&1


####################################################### 15:50 docker for trading so not kill ######################################################################################################################################## 

15 8 * * 1-5 (echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/job.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/job.log 2>&1


#################### Docker and Data download ######################

*/20 9-15 * * 1-5 (echo "----- $(date) -----" && sudo docker pull jinwei6499/s2prox:v1) >> /home/user7496/Desktop/s2prox_jobs/dockerpull.log 2>&1


#################### S2Pro7 Trading and PIN ibrk  ################# 

# 31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/soxl7_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/soxl7_reb.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXS80_REB.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/SOXS80_REB.log 2>&1
#59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/tsll.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/tsll.log 2>&1
#59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/COIN.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/COIN.log 2>&1

40 8-15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1



#################### S2Pro7 Updated stoploss ################# 

2 16 * * 1-5 (echo "----- $(date) -----" && sudo docker ps -q | xargs -r sudo docker kill) >> /home/user7496/Desktop/s2prox_jobs/logfile/kill.log 2>&1


# no taoli
#*/3 9-15 * * 1-5 /home/user7496/Desktop/s2prox_jobs/run_long_new_notaoli.sh >> /home/user7496/Desktop/s2prox_jobs/logfile/run_long.log 2>&1


# normal daily
#*/3 9-15 * * 1-5 /home/user7496/Desktop/s2prox_jobs/run_long_new_normal.sh >> /home/user7496/Desktop/s2prox_jobs/logfile/run_long.log 2>&1


# right now
*/3 9-15 * * 1-5 /home/user7496/Desktop/s2prox_jobs/run_long_new_NOW.sh >> /home/user7496/Desktop/s2prox_jobs/logfile/run_long.log 2>&1


# stop and clear  all taoli 
# */3 9-15 * * 1-5 /home/user7496/Desktop/s2prox_jobs/run_long_new_closeall.sh >> /home/user7496/Desktop/s2prox_jobs/logfile/run_long.log 2>&1

"""



# Step 1: 获取美股市场的交易日历
nyse = mcal.get_calendar('NYSE')

# Step 2: 获取今天的交易日信息
today = datetime.now() 
print(today)
schedule = nyse.schedule(start_date=today.strftime('%Y-%m-%d'), end_date=today.strftime('%Y-%m-%d'))

# 如果今天不是交易日，只保留 job.py 任务
if schedule.empty:
    print("今天不是交易日，清空交易相关的 crontab，保留 job.py 的任务")
    
    # 获取当前的 crontab
    current_cron = subprocess.run(["crontab", "-l"], capture_output=True, text=True).stdout
    updated_cron = []
    
    for line in current_cron.splitlines():
        if "job.py" in line:  # 仅保留与 job.py 相关的任务
            updated_cron.append(line)
    
    # 写回更新后的 crontab
    subprocess.run(["crontab", "-"], input="\n".join(updated_cron)+"\n", text=True)
    exit()

# Step 3: 获取市场收盘时间
close_time_utc = schedule['market_close'].iloc[0].to_pydatetime()
eastern_tz = pytz.timezone('America/New_York')
close_time_eastern = close_time_utc.astimezone(eastern_tz)
trade_time = close_time_eastern - timedelta(seconds=10)
cron_minute = trade_time.minute
cron_hour = trade_time.hour

# Step 4: 更新交易相关的任务，确保 $(date) 保持动态执行
updated_cron_lines = []
for line in original_crontab.splitlines():
    if line.startswith("59 15 * * 1-5"):
        updated_line = line.replace("59 15", f"{cron_minute} {cron_hour}")
    else:
        updated_line = line  # 保持原样

    # **关键修正：确保 $(date) 不被 Python 替换**
    updated_line = updated_line.replace("$(date)", r'$(date)')

    updated_cron_lines.append(updated_line)

# Step 5: 使用 `subprocess` 写入更新后的 crontab
updated_cron = "\n".join(updated_cron_lines) + "\n"
subprocess.run(["crontab", "-"], input=updated_cron, text=True)

print(f"✅ Crontab 已更新，动态任务时间设置为 {cron_hour}:{cron_minute}")









