import csv
import subprocess

# Path to the CSV file
csv_file = '/home/user7496/Desktop/s2prox_jobs/users_config.csv'

# List of accounts you want to run (empty means all accounts will run)
specific_accounts = ["123"]  # Example: ["U14301234", "U5947157"]  # Add the account IDs you want to run

# Read the CSV file and execute Docker commands for each user
with open(csv_file, 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        ACCOUNT = row['ACCOUNT']
        MARGIN = row['MARGIN']
        TRANSMIT = row['TRANSMIT']
        HOST = row['HOST']
        PORT = row['PORT']
        CSV_PATH = row.get('CSV_PATH', '/app/downloads/s2prox/S2Proxdata.csv')  # Use default if not provided

        # Check if this account should be run
        if specific_accounts and ACCOUNT not in specific_accounts:
            continue  # Skip this account if it's not in the list

        # Build the Docker command
        docker_command = [
            'sudo', 'docker', 'run', '--rm', '--network=host',
            '-e', f'MARGIN={MARGIN}',
            '-e', f'TRANSMIT={TRANSMIT}',
            '-e', f'ACCOUNT={ACCOUNT}',
            '-e', f'HOST={HOST}',
            '-e', f'PORT={PORT}',
            '-e', f'CSV_PATH={CSV_PATH}',  # Include the CSV_PATH environment variable
            '-v', 's2prox-volume:/app/downloads/s2prox',
            'jinwei6499/s2prox:v1', 'python', './s2prox7_wenxiang.py'
        ]

        # Execute the Docker command for the current user
        subprocess.Popen(docker_command)
