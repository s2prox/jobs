#!/bin/bash

# 获取当前纽约时间
NY_HOUR_MIN=$(TZ="America/New_York" date +"%H:%M")
NY_TIME=$(TZ="America/New_York" date +"%Y%m%d_%H%M")

 sleep 30

# 定义日志目录
LOG_DIR="/home/user7496/Desktop/s2prox_jobs/logfile"
mkdir -p "$LOG_DIR"

# --- Step 1: Kill Docker containers ---
echo "----- $(date) -----" | tee -a "$LOG_DIR/kill_$NY_TIME.log"
sudo docker kill $(sudo docker ps -q) >> "$LOG_DIR/kill_$NY_TIME.log" 2>&1

# --- Step 2: 根据时间运行对应脚本 ---


 echo "----- $(date) -----" | tee -a "$LOG_DIR/SOXL_PRO7_212_$NY_TIME.log"
 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXL_PRO7_212.py >> "$LOG_DIR/SOXL_PRO7_212_$NY_TIME.log" 2>&1 &