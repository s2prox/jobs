#!/bin/bash

# Get current New York time in YYYYMMDD_HHMM format
NY_TIME=$(TZ="America/New_York" date +"%Y%m%d_%H%M")
NY_HM=$(TZ="America/New_York" date +"%H:%M")



# Define base log directory
LOG_DIR="/home/user7496/Desktop/s2prox_jobs/logfile"



# Make sure log directory exists
mkdir -p "$LOG_DIR"


# --- Step 1: Kill Docker containers ---
echo "----- $(date) -----" | tee -a "$LOG_DIR/kill_$NY_TIME.log"
sudo docker kill $(sudo docker ps -q) >> "$LOG_DIR/kill_$NY_TIME.log" 2>&1




# --- Step 2: Run container to delete .csv files in Docker volume ---
sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox ubuntu bash -c "rm -f /app/downloads/s2prox/*.csv"



(echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/close_price.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/close_price.log 2>&1



(echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl.log 2>&1


/home/user7496/Desktop/s2prox_jobs/run_long_new_normal.sh >> /home/user7496/Desktop/s2prox_jobs/logfile/run_long.log 2>&1