import os
import subprocess
from datetime import datetime, timedelta
import pandas_market_calendars as mcal
import pytz

# Original crontab jobs as a string

original_crontab = """

#  make sure vm work smoothly
0 * * * * sudo pkill -f JxBrowser

#111##### pull docker images everyday
0 8,15 * * 1-5 (echo "----- $(date) -----" && sudo docker pull jinwei6499/s2prox:v1) >> /home/user7496/Desktop/s2prox_jobs/dockerpull.log 2>&1

15 8 * * 1-5 (echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/job.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/job.log 2>&1



#222##### Download the trading data and soxx components 
31,32 9 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_prices.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl_prices.log 2>&1

30 10 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl.log 2>&1

35 10 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_soxx.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl_soxx.log 2>&1


#333##### [50% S2Pro7 via AMD NVDA ASML ]   
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_SOXX_Half.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_reb_again.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_SOXX_Half_Again.log 2>&1

31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_SOXX_half_stp.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_SOXX_half_stp.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_SOXX_half_stp.log 2>&1


#444##### [50% S2Prox100]  
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox100_half_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox100_half_rebalance.log 2>&1


#555##### [50%pro7x+50%pro77]  half-half-soxl in the same account
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro77_s2pro7x_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro77_s2pro7x_rebalance.log 2>&1

#666##### [s2pro7]   
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp_limited.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_rebalance.log 2>&1

#666-2 stoploss for pro7 via everyminutes 
33-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp_MKT.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp_MKT.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp_MKT.log 2>&1


#777## 80% X100RC_pre_open
27 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_pre_open.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_pre_open.log 2>&1
#777##### [80% x100 soxl buy back/ stoploss]   
# 33-40 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp.log 2>&1
# 0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp.log 2>&1
# 0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp.log 2>&1
# 777 100% x100_soxl rebalance at the end of the market
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_reb_x100.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_X100_rebalance.log 2>&1

#777##### [download trading data at 1st minuet to buy back/ stoploss ]   
33-40 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
#0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
#0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
#777 100% x100_soxl rebalance at the end of the market



#777##### [download trading data at 1st minuet to buy back/ stoploss ]   
32-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100RC_stp_dl.log 2>&1
#777 100% x100_soxl rebalance at the end of the market


#888##### Check if IBKR disconnected
*/7 9-16 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1
32 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1

#30,54 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1
#999##### Pin IBKR at 15:57
57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/pin_test.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/pin_test.log 2>&1

"""



# Step 1: 获取美股市场的交易日历
nyse = mcal.get_calendar('NYSE')

# Step 2: 获取今天的交易日信息
today = datetime.now() 
print(today)
schedule = nyse.schedule(start_date=today.strftime('%Y-%m-%d'), end_date=today.strftime('%Y-%m-%d'))

# 如果今天不是交易日，只保留 job.py 任务
if schedule.empty:
    print("今天不是交易日，清空交易相关的 crontab，保留 job.py 的任务")
    
    # 获取当前的 crontab
    current_cron = subprocess.run(["crontab", "-l"], capture_output=True, text=True).stdout
    updated_cron = []
    
    for line in current_cron.splitlines():
        if "job.py" in line:  # 仅保留与 job.py 相关的任务
            updated_cron.append(line)
    
    # 写回更新后的 crontab
    subprocess.run(["crontab", "-"], input="\n".join(updated_cron)+"\n", text=True)
    exit()

# Step 3: 获取市场收盘时间
close_time_utc = schedule['market_close'].iloc[0].to_pydatetime()
eastern_tz = pytz.timezone('America/New_York')
close_time_eastern = close_time_utc.astimezone(eastern_tz)
trade_time = close_time_eastern - timedelta(seconds=10)
cron_minute = trade_time.minute
cron_hour = trade_time.hour

# Step 4: 更新交易相关的任务，确保 $(date) 保持动态执行
updated_cron_lines = []
for line in original_crontab.splitlines():
    if line.startswith("59 15 * * 1-5"):
        updated_line = line.replace("59 15", f"{cron_minute} {cron_hour}")
    else:
        updated_line = line  # 保持原样

    # **关键修正：确保 $(date) 不被 Python 替换**
    updated_line = updated_line.replace("$(date)", r'$(date)')

    updated_cron_lines.append(updated_line)

# Step 5: 使用 `subprocess` 写入更新后的 crontab
updated_cron = "\n".join(updated_cron_lines) + "\n"
subprocess.run(["crontab", "-"], input=updated_cron, text=True)

print(f"✅ Crontab 已更新，动态任务时间设置为 {cron_hour}:{cron_minute}")









