import os
from datetime import datetime, timedelta
import pandas_market_calendars as mcal
import pytz

# Original crontab jobs as a string
original_crontab = """

0 9 * * 0 sudo reboot

### pro7 rebanlance_again
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_reb_again.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_reb_again.log 2>&1
### x100_soxl rebalance , stoploss is the save as prox
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_reb_x100.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro_X100.log 2>&1
### x100 and X mixing rebalance , stoploss is the save as prox
#59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_reb_x_x100_mix.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro_X100_mixing.log 2>&1

###### [80% x100_SOXX rebalance ]   
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance_x100.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_rebalance_20.log 2>&1
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_20.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_20.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_20.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_20.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_20.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_20.log 2>&1
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_0.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_0.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp_0.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/x100_nvda_stp_0.log 2>&1



#111##### pull docker images everyday
0 8 * * 1-5 (echo "----- $(date) -----" && sudo docker pull jinwei6499/s2prox:v1) >> /home/user7496/Desktop/s2prox_jobs/logfile/dockerpull.log 2>&1

15 8 * * 1-5 (echo "----- $(date) -----" && python3 /home/user7496/Desktop/s2prox_jobs/job.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/job.log 2>&1

#222##### Download the trading data and soxx components 
30 10 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl.log 2>&1
35 10 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_soxx.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl_soxx.log 2>&1

#333##### [50% S2Pro7]  333 + 444 use together
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_rebalance.log 2>&1
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1


#3332##### [50% S2Pro7]  333 + 444 use together
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1

#444##### [50% S2Prox]  333 + 444 use together
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_half_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_half_rebalance.log 2>&1


#555##### [50%proxX+50%prox7]  half-half-soxl in the same account
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_full_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_full_rebalance.log 2>&1

#666##### [s2pro7]   
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_rebalance.log 2>&1


#777##### Check if IBKR disconnected
0,24 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1
30,54 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1

#888##### Pin IBKR at 15:57
57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/pin_test.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/pin_test.log 2>&1

"""

# Step 1: 获取美股市场的交易日历
nyse = mcal.get_calendar('NYSE')

# Step 2: 获取今天的交易日信息
today = datetime.now()
schedule = nyse.schedule(start_date=today.strftime('%Y-%m-%d'), end_date=today.strftime('%Y-%m-%d'))

# 如果今天不是交易日，只保留 job.py 的任务
if schedule.empty:
    print("今天不是交易日，清空交易相关的 crontab，保留 job.py 的任务")
    # 获取当前的 crontab
    current_cron = os.popen("crontab -l").read()
    updated_cron = []
    for line in current_cron.splitlines():
        if "job.py" in line:  # 仅保留与 job.py 相关的任务
            updated_cron.append(line)
    # 写回更新后的 crontab
    os.system(f'(echo "{chr(10).join(updated_cron)}") | crontab -')
    exit()

# Step 3: 获取市场收盘时间
close_time_utc = schedule['market_close'].iloc[0].to_pydatetime()
eastern_tz = pytz.timezone('America/New_York')
close_time_eastern = close_time_utc.astimezone(eastern_tz)
trade_time = close_time_eastern - timedelta(seconds=30)
cron_minute = trade_time.minute
cron_hour = trade_time.hour

# Step 4: 更新交易相关的任务
updated_cron_lines = []
for line in original_crontab.splitlines():
    if line.startswith("59 15 * * 1-5"):
        updated_line = line.replace("59 15", f"{cron_minute} {cron_hour}")
        updated_cron_lines.append(updated_line)
    else:
        updated_cron_lines.append(line)

# Step 5: 写入更新后的 crontab
updated_cron = "\n".join(updated_cron_lines)
os.system(f'(echo "{updated_cron.strip()}") | crontab -')

print(f"已更新 crontab，动态任务时间设置为 {cron_hour}:{cron_minute}")
