#!/bin/bash

# Get current New York time in YYYYMMDD_HHMM format


# Get current New York time in YYYYMMDD_HHMM format
NY_TIME=$(TZ="America/New_York" date +"%Y%m%d_%H%M")
NY_HM=$(TZ="America/New_York" date +"%H:%M")

# If not 09:30 New York time, sleep 2s
#if [ "$NY_HM" != "09:30" ]; then
#    sleep 15
#fi

sleep 30

# Define base log directory
LOG_DIR="/home/user7496/Desktop/s2prox_jobs/logfile"


# Make sure log directory exists
mkdir -p "$LOG_DIR"

# --- Step 1: Kill Docker containers ---
echo "----- $(date) -----" | tee -a "$LOG_DIR/kill_$NY_TIME.log"
sudo docker kill $(sudo docker ps -q) >> "$LOG_DIR/kill_$NY_TIME.log" 2>&1


# --- Step 5: Run TSLA_SHORT.py ---
#echo "----- $(date) -----" | tee -a "$LOG_DIR/SOXL_IND_U8507_P10_STP_$NY_TIME.log"
#/usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXL_IND_U8507_P10_STP.py >> "$LOG_DIR/SOXL_IND_U8507_P10_STP_$NY_TIME.log" 2>&1 &


# --- Step 6: Run TSLA_SHORT.py ---
#echo "----- $(date) -----" | tee -a "$LOG_DIR/SOXL_IND_U2782_P9_STP_$NY_TIME.log"
#/usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXL_IND_U2782_P9_STP.py >> "$LOG_DIR/SOXL_IND_U2782_P9_STP_$NY_TIME.log" 2>&1 &


 echo "----- $(date) -----" | tee -a "$LOG_DIR/SOXL_PRO7_212_$NY_TIME.log"
 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXL_PRO7_212.py >> "$LOG_DIR/SOXL_PRO7_212_$NY_TIME.log" 2>&1 &


# echo "----- $(date) -----" | tee -a "$LOG_DIR/ETHU_0525_$NY_TIME.log"
# /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ethu.py >> "$LOG_DIR/ETHU_0525_$NY_TIME.log" 2>&1 &


# echo "----- $(date) -----" | tee -a "$LOG_DIR/SOXS80_0523_$NY_TIME.log"
/usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXS80_0523.py >> "$LOG_DIR/SOXS80_0523_$NY_TIME.log" 2>&1 &


# echo "----- $(date) -----" | tee -a "$LOG_DIR/TSLL_HF_$NY_TIME.log"
/usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXL_HF.py >> "$LOG_DIR/SOXL_HF_$NY_TIME.log" 2>&1 &

