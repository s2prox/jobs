#111##### pull docker images everyday
0 8 * * 1-5 (echo "----- $(date) -----" && sudo docker pull jinwei6499/s2prox:v1) >> /home/user7496/Desktop/s2prox_jobs/logfile/dockerpull.log 2>&1

#222##### Download the trading data and soxx components 
30 15 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl.log 2>&1
35 15 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_soxx.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/dl_soxx.log 2>&1

#333##### [50% S2Pro7]  333 + 444 use together
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_rebalance.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_reb_again.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_reb_again.log 2>&1
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_half_stp.log 2>&1


#3332##### [50% S2Pro7]  333 + 444 use together
31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1
0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1
0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_open_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/open_stp.log 2>&1


#444##### [50% S2Prox]  333 + 444 use together
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_half_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_half_rebalance.log 2>&1

#555##### [50%proxX+50%prox7]  half-half-soxl in the same account
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_full_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2prox_full_rebalance.log 2>&1

#666##### [s2pro7]   
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_stp.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_stp.log 2>&1
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/s2pro7_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/s2pro7_rebalance.log 2>&1


#777##### Check if IBKR disconnected
0,24 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1
30,54 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/ibkr_connection.log 2>&1

#888##### Pin IBKR at 15:57
57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/pin_test.py) >> /home/user7496/Desktop/s2prox_jobs/logfile/pin_test.log 2>&1
