#111##### pull docker images everyday
0 8 * * 1-5 (echo "----- $(date) -----" && newgrp docker && docker login && docker pull jinwei6499/s2prox:v1) >> /home/user7496/Desktop/s2prox_jobs/dockerpull.log 2>&1

#222##### Download the data
30 15 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py) >> /home/user7496/Desktop/s2prox_jobs/dl.log 2>&1
35 15 * * 1-5 (echo "----- $(date) -----" && sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_soxx.py) >> /home/user7496/Desktop/s2prox_jobs/dl_soxx.log 2>&1

#333##### Rebalance SOXX holding list
#59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.log 2>&1
#Stop SOXX holding lists
#31-59 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1
#0-59 10-14 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1
#0-57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py) >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1

#444##### Stoploss SOXL
31 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_stp.py) >> /home/user7496/Desktop/s2prox_jobs/soxl_stp.log 2>&1
# Rebalance SOXL
59 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.py) >> /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.log 2>&1

#555##### Check if IBKR disconnected
0,24 9 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/ibkr_connection.log 2>&1
30,54 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py) >> /home/user7496/Desktop/s2prox_jobs/ibkr_connection.log 2>&1
# Pin IBKR at 15:57
57 15 * * 1-5 (echo "----- $(date) -----" && /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/pin_test.py) >> /home/user7496/Desktop/s2prox_jobs/pin_test.log 2>&1

