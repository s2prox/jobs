# download the data
45 15 * * 1-5 sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl.py >> /home/user7496/Desktop/s2prox_jobs/dl.log 2>&1
50 15 * * 1-5 sudo docker run --rm -v s2prox-volume:/app/downloads/s2prox jinwei6499/s2prox:v1 python ./dl_soxx.py >> /home/user7496/Desktop/s2prox_jobs/dl_soxx.log 2>&1


###### rebalance SOXX holding list
59 15 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.py >> /home/user7496/Desktop/s2prox_jobs/SOXX_rebalance.log 2>&1
# stop soxx holding lists
31-59 9 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1
* 10-14 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1
0-57 15 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/SOXX_stp.py >> /home/user7496/Desktop/s2prox_jobs/SOXX_stp.log 2>&1


# stoploss soxl
31 9 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_stp.py >> /home/user7496/Desktop/s2prox_jobs/soxl_stp.log 2>&1
# rebalance soxl
59 15 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.py >> /home/user7496/Desktop/s2prox_jobs/soxl_rebalance.log 2>&1


###### check if ibkr disconected
0,24 9 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py >> /home/user7496/Desktop/s2prox_jobs/ibkr_connection.log 2>&1
30,54 15 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/ibkr_connection.py >> /home/user7496/Desktop/s2prox_jobs/ibkr_connection.log 2>&1
# pin ibkr at 15:57
57 15 * * 1-5 /usr/bin/python3 /home/user7496/Desktop/s2prox_jobs/pin_test.py >> /home/user7496/Desktop/s2prox_jobs/pin_test.log 2>&1
