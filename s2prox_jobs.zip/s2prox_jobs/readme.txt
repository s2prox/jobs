dl.py: download trading data 
dl_soxx:  download soxx holding lists 
ibkr96:   check ibkr connection or not 

Margin = 1
pro796:--IRA account--series   for the code soxl7_rebalance  [s2prox data] with both [s2prox and s2pro7] trading method in same account
s2pro796:--s2pro7 only--series for the code s2pro7_rebalance [s2pro7 data] with [s2pro7] trading method in the same account

Margin = 0.5 s2prox/2 + s2pro7/2
-- the following two used together for [half prox and half pro7] operation 
prox96:   series for the code soxl_rebalance   [s2prox data] with [s2prox] trading method
stk96:    series for the code SOXX_rebalance   [S2pro7 data]  with [s2pro7] trading method


plan to change to 
Margin = 0.5 s2prox100/2 + s2prox7/2
-- the following two used together for [half prox and half pro7] operation 
prox96:   series for the code soxl_rebalance   [s2prox100 data] with [s2prox] trading method
stk96:    series for the code SOXX_rebalance   [S2prox data]  with [s2pro7] trading method
