#!/bin/bash
set -e

echo "Installing systemd services..."

sudo cp systemd/s2prox_soxx.service /etc/systemd/system/
sudo cp systemd/s2prox_qqq.service /etc/systemd/system/

sudo systemctl daemon-reload
sudo systemctl enable s2prox_soxx
sudo systemctl enable s2prox_qqq

sudo systemctl start s2prox_soxx
sudo systemctl start s2prox_qqq

echo "All services installed and started."
