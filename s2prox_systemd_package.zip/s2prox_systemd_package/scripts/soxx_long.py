#!/usr/bin/env python3
print('Running soxx_long strategy...')