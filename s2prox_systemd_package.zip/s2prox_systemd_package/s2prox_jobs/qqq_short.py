#!/usr/bin/env python3
# qqq_short strategy logic here
