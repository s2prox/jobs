#!/usr/bin/env python3
# soxx_long strategy logic here
