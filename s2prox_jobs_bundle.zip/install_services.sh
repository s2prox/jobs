#!/bin/bash
set -e
SERVICES=("soxx" "afternoon")
for SVC in "${SERVICES[@]}"; do
  SERVICE_FILE="/etc/systemd/system/s2prox_${SVC}.service"
  SCRIPT_PATH="/home/user7496/Desktop/s2prox_jobs/${SVC}.py"
  LOG_PATH="/home/user7496/Desktop/s2prox_jobs/logfile/${SVC}.log"

  sudo bash -c "cat > $SERVICE_FILE" <<EOF
[Unit]
Description=S2ProX ${SVC^} Trading Daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 $SCRIPT_PATH
Restart=always
RestartSec=2
StandardOutput=append:$LOG_PATH
StandardError=append:$LOG_PATH

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable s2prox_${SVC}
  sudo systemctl start s2prox_${SVC}
done
echo "✅ All services installed and started."
