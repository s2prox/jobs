#!/bin/bash
set -e
SERVICES=("soxx" "afternoon")
for SVC in "${SERVICES[@]}"; do
  sudo systemctl stop s2prox_${SVC}
  sudo systemctl disable s2prox_${SVC}
  sudo rm -f /etc/systemd/system/s2prox_${SVC}.service
done
sudo systemctl daemon-reload
echo "🧹 All services removed."
