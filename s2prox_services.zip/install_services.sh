#!/bin/bash

SCRIPT_DIR="/home/user7496/Desktop/s2prox_jobs"
LOG_DIR="$SCRIPT_DIR/logfile"

mkdir -p "$LOG_DIR"

cat <<EOF | sudo tee /etc/systemd/system/s2prox_soxx.service > /dev/null
[Unit]
Description=S2ProX SOXX Long Strategy Daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 $SCRIPT_DIR/soxx_long.py
Restart=always
StandardOutput=append:$LOG_DIR/soxx_long.log
StandardError=append:$LOG_DIR/soxx_long.log

[Install]
WantedBy=multi-user.target
EOF

cat <<EOF | sudo tee /etc/systemd/system/s2prox_qqq.service > /dev/null
[Unit]
Description=S2ProX QQQ Short Strategy Daemon
After=network.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 $SCRIPT_DIR/qqq_short.py
Restart=always
StandardOutput=append:$LOG_DIR/qqq_short.log
StandardError=append:$LOG_DIR/qqq_short.log

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable --now s2prox_soxx.service
sudo systemctl enable --now s2prox_qqq.service

echo "✅ Services installed and started."
