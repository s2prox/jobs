#!/bin/bash

sudo systemctl stop s2prox_soxx.service
sudo systemctl stop s2prox_qqq.service
sudo systemctl disable s2prox_soxx.service
sudo systemctl disable s2prox_qqq.service
sudo rm -f /etc/systemd/system/s2prox_soxx.service
sudo rm -f /etc/systemd/system/s2prox_qqq.service
sudo systemctl daemon-reload

echo "🗑️ Services uninstalled."
